﻿
namespace MissingBreeze.Event.Utils
{
    public class SingletonUtils<T> where T : class, new()
    {
        /// <summary>
        /// 单例
        /// </summary>
        private static T _instance;

        /// <summary>
        /// 锁
        /// </summary>
        private static readonly object syslock = new object();

        /// <summary>
        /// 取得单例实例
        /// </summary>
        /// <returns></returns>
        public static T Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (syslock)
                    {
                        if (_instance == null)
                        {
                            _instance = new T();
                        }
                    }
                }
                return _instance;
            }
            private set
            {

            }
        }
    }
}
