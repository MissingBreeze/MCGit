﻿
namespace MissingBreeze.Event.Event
{
    /// <summary>
    /// 事件数据
    /// </summary>
    public class EventData
    {
        /// <summary>
        /// 无参构造函数
        /// </summary>
        public EventData()
        {
        }
    }
}
